Collected & curated from http://stateoftheunion.onetwothree.net/texts/index.html
September 25,2014
March 16,2015

Debates curated from http://www.presidency.ucsb.edu/debates.php
March 16,2015

