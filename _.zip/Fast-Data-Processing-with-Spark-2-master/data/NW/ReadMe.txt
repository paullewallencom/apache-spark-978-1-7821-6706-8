For those who remember the Microsoft access database, this was the canonical test data for training and experimentation. The data is available in the net Northwind (2003) & Northwind (2013)
[Northwind, 2003] Northwind Traders Database http://yunus.hacettepe.edu.tr/~tonta/courses/spring2003/dok322/
[Northwind, 2013]https://code.google.com/p/northwindextended/
