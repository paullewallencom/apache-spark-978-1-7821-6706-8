Collected & curated from AirlinesCluster.csv (https://courses.edx.org/c4x/MITx/15.071x/asset/AirlinesCluster.csv) 
September 27,2014
The data was part of the assignment for the edX course MITx: 15.071x The Analytics Edge 
